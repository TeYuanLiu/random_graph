We have five code files in total and one report file.
Please use the command "Rscript filename.r" to execute our R scripts in the terminal of a linux machine with R installed.
Please use jupyter notebook with R kernel installed to execute our notebook files.
